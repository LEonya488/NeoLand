package dev.neo.adaptivewall;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.WallpaperManager;
import android.app.role.RoleManager;
import android.content.ComponentName;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.PointF;
import android.graphics.RectF;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.os.SystemClock;
import android.provider.Settings;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.HapticFeedbackConstants;
import android.view.MotionEvent;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.Toast;

import java.text.Collator;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.Locale;

/** Optional replacement home screen. Never becomes the default without user consent. */
public final class HomeActivity extends Activity {
    private static final int MAX_HOME_APPS = 16;
    private final List<AppEntry> available = new ArrayList<>();
    private final List<AppEntry> homeApps = new ArrayList<>();
    private ScenePrefs preferences;
    private HomeView homeView;

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        preferences = new ScenePrefs(this);
        getWindow().setStatusBarColor(Color.rgb(4, 49, 71));
        getWindow().setNavigationBarColor(Color.rgb(4, 49, 71));
        loadApps();
        homeView = new HomeView();
        setContentView(homeView);
    }

    @Override protected void onResume() {
        super.onResume();
        loadApps();
        if (homeView != null) homeView.setAnimating(true);
    }

    @Override protected void onPause() {
        if (homeView != null) homeView.setAnimating(false);
        super.onPause();
    }

    private void loadApps() {
        PackageManager pm = getPackageManager();
        Intent query = new Intent(Intent.ACTION_MAIN);
        query.addCategory(Intent.CATEGORY_LAUNCHER);
        List<ResolveInfo> resolved = pm.queryIntentActivities(query, 0);
        available.clear();
        for (ResolveInfo info : resolved) {
            if (info.activityInfo == null || getPackageName().equals(info.activityInfo.packageName)) continue;
            ComponentName name = new ComponentName(info.activityInfo.packageName, info.activityInfo.name);
            CharSequence label = info.loadLabel(pm);
            available.add(new AppEntry(name, label == null ? name.getShortClassName() : label.toString(),
                    info.loadIcon(pm)));
        }
        Collator collator = Collator.getInstance(new Locale("ru"));
        Collections.sort(available, (a, b) -> collator.compare(a.label, b.label));

        String pinned = preferences.pinned();
        if (pinned == null) {
            StringBuilder firstApps = new StringBuilder();
            for (int i = 0; i < Math.min(12, available.size()); i++) {
                if (firstApps.length() != 0) firstApps.append('\n');
                firstApps.append(available.get(i).key());
            }
            pinned = firstApps.toString();
            preferences.setPinned(pinned);
        }

        homeApps.clear();
        for (String key : pinned.split("\n")) {
            for (AppEntry item : available) {
                if (item.key().equals(key) && homeApps.size() < MAX_HOME_APPS) {
                    homeApps.add(item);
                    break;
                }
            }
        }
        if (homeView != null) homeView.invalidate();
    }

    private void savePinned() {
        StringBuilder builder = new StringBuilder();
        for (AppEntry item : homeApps) {
            if (builder.length() != 0) builder.append('\n');
            builder.append(item.key());
        }
        preferences.setPinned(builder.toString());
        if (homeView != null) homeView.invalidate();
    }

    private void openDrawer() {
        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        int pad = Math.round(dp(16));
        layout.setPadding(pad, pad / 2, pad, 0);
        EditText search = new EditText(this);
        search.setSingleLine(true);
        search.setHint("Найти приложение…");
        layout.addView(search, new LinearLayout.LayoutParams(-1, -2));

        ListView list = new ListView(this);
        layout.addView(list, new LinearLayout.LayoutParams(-1, Math.round(dp(420))));
        List<AppEntry> filtered = new ArrayList<>();
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this,
                android.R.layout.simple_list_item_1, new ArrayList<>());
        list.setAdapter(adapter);

        Runnable refresh = () -> {
            String term = search.getText().toString().trim().toLowerCase(Locale.ROOT);
            filtered.clear();
            adapter.clear();
            for (AppEntry item : available) {
                if (!item.label.toLowerCase(Locale.ROOT).contains(term)) continue;
                filtered.add(item);
                adapter.add((contains(item) ? "✓  " : "+  ") + item.label);
            }
            adapter.notifyDataSetChanged();
        };
        refresh.run();
        search.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) { }
            @Override public void onTextChanged(CharSequence s, int start, int before, int count) { refresh.run(); }
            @Override public void afterTextChanged(Editable s) { }
        });
        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle("Все приложения")
                .setMessage("Нажми для запуска. Долгое нажатие — добавить или убрать значок с главного экрана.")
                .setView(layout)
                .setPositiveButton("Готово", null)
                .create();
        list.setOnItemClickListener((parent, view, position, id) -> {
            AppEntry item = filtered.get(position);
            dialog.dismiss();
            openApp(item);
        });
        list.setOnItemLongClickListener((parent, view, position, id) -> {
            AppEntry item = filtered.get(position);
            if (contains(item)) {
                homeApps.removeIf(app -> app.key().equals(item.key()));
            } else if (homeApps.size() >= MAX_HOME_APPS) {
                Toast.makeText(this, "На экране пока помещается 16 значков", Toast.LENGTH_SHORT).show();
                return true;
            } else {
                homeApps.add(item);
            }
            savePinned();
            refresh.run();
            return true;
        });
        dialog.show();
    }

    private boolean contains(AppEntry entry) {
        for (AppEntry item : homeApps) if (item.key().equals(entry.key())) return true;
        return false;
    }

    private void openApp(AppEntry app) {
        Intent intent = new Intent(Intent.ACTION_MAIN);
        intent.addCategory(Intent.CATEGORY_LAUNCHER);
        intent.setComponent(app.component);
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED);
        try { startActivity(intent); }
        catch (Exception e) {
            Toast.makeText(this, "Не удалось открыть " + app.label, Toast.LENGTH_SHORT).show();
        }
    }

    private void makeDefaultHome() {
        RoleManager roles = getSystemService(RoleManager.class);
        if (roles != null && roles.isRoleAvailable(RoleManager.ROLE_HOME)) {
            if (roles.isRoleHeld(RoleManager.ROLE_HOME)) {
                Toast.makeText(this, "Neo Land уже выбран главным экраном", Toast.LENGTH_SHORT).show();
            } else {
                startActivityForResult(roles.createRequestRoleIntent(RoleManager.ROLE_HOME), 101);
            }
        } else {
            startActivity(new Intent(Settings.ACTION_HOME_SETTINGS));
        }
    }

    private void setLiveWallpaper() {
        Intent intent = new Intent(WallpaperManager.ACTION_CHANGE_LIVE_WALLPAPER);
        intent.putExtra(WallpaperManager.EXTRA_LIVE_WALLPAPER_COMPONENT,
                new ComponentName(this, AdaptiveWallpaperService.class));
        try { startActivity(intent); }
        catch (Exception e) {
            Toast.makeText(this, "Открой живые обои в настройках телефона", Toast.LENGTH_LONG).show();
        }
    }

    private float dp(float value) { return value * getResources().getDisplayMetrics().density; }

    private static final class AppEntry {
        final ComponentName component;
        final String label;
        final Drawable icon;
        AppEntry(ComponentName component, String label, Drawable icon) {
            this.component = component;
            this.label = label;
            this.icon = icon;
        }
        String key() { return component.flattenToString(); }
    }

    private final class HomeView extends View {
        private final SceneRenderer renderer = new SceneRenderer();
        private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final List<RectF> zones = new ArrayList<>();
        private final List<RectF> iconBoxes = new ArrayList<>();
        private final SimpleDateFormat clockFormat = new SimpleDateFormat("HH:mm", Locale.getDefault());
        private final RectF beachButton = new RectF();
        private final RectF meadowButton = new RectF();
        private final RectF appsButton = new RectF();
        private final RectF wallpaperButton = new RectF();
        private final RectF defaultButton = new RectF();
        private boolean animating = true;
        private AppEntry touched;
        private AppEntry dragging;
        private float startX, startY, fingerX, fingerY;
        private Runnable longPress;

        HomeView() { super(HomeActivity.this); }

        void setAnimating(boolean value) {
            animating = value;
            if (value) invalidate();
        }

        @Override protected void onDraw(Canvas canvas) {
            super.onDraw(canvas);
            int w = getWidth(), h = getHeight();
            if (w <= 0 || h <= 0) return;

            // Every icon box is an obstacle passed to the adaptive landscape renderer.
            zones.clear(); iconBoxes.clear();
            for (int i = 0; i < homeApps.size(); i++) {
                AppEntry app = homeApps.get(i);
                PointF position = preferences.getIconPosition(app.key(), i);
                float x = (app == dragging) ? fingerX : w * position.x;
                float y = (app == dragging) ? fingerY : h * position.y;
                RectF box = new RectF(x - dp(39), y - dp(45), x + dp(39), y + dp(48));
                iconBoxes.add(box); zones.add(new RectF(box));
            }
            renderer.render(canvas, w, h, getResources().getDisplayMetrics().density,
                    SystemClock.uptimeMillis(), preferences.theme(), zones);

            // Readable UI over both bright and dark themes.
            label(canvas, "NEO LAND", dp(22), dp(31), dp(15), 0xFFF7FFFC, true, false);
            label(canvas, "АДАПТИВНЫЙ ЖИВОЙ ЭКРАН", dp(22), dp(50), dp(9), 0xD4F7FFFC, false, false);
            float top = dp(64);
            float margin = dp(15);
            float gap = dp(8);
            float availableWidth = w - margin * 2 - gap * 2;
            float smallWidth = availableWidth * .275f;
            beachButton.set(margin, top, margin + smallWidth, top + dp(38));
            meadowButton.set(beachButton.right + gap, top, beachButton.right + gap + smallWidth, top + dp(38));
            appsButton.set(meadowButton.right + gap, top, w - margin, top + dp(38));
            button(canvas, beachButton, "ПЛЯЖ", SceneRenderer.BEACH.equals(preferences.theme()));
            button(canvas, meadowButton, "ЛУГ", SceneRenderer.MEADOW.equals(preferences.theme()));
            button(canvas, appsButton, "+ ПРИЛОЖЕНИЯ", false);

            label(canvas, clockFormat.format(new Date()), dp(20), dp(168), dp(46), 0xFFFFFFFF, true, false);
            label(canvas, "Долгое нажатие — переместить значок", dp(21), dp(192), dp(11), 0xE1FFFFFF, false, false);

            for (int i = 0; i < homeApps.size(); i++) {
                RectF box = iconBoxes.get(i);
                AppEntry app = homeApps.get(i);
                paint.reset(); paint.setAntiAlias(true); paint.setColor(0x35203341);
                canvas.drawRoundRect(box, dp(20), dp(20), paint);
                float iconSize = dp(49);
                int l = Math.round(box.centerX() - iconSize / 2);
                int t = Math.round(box.centerY() - dp(32));
                app.icon.setBounds(l, t, l + Math.round(iconSize), t + Math.round(iconSize));
                app.icon.draw(canvas);
                String shortened = shorten(app.label, 12);
                label(canvas, shortened, box.centerX(), box.centerY() + dp(34),
                        dp(10), Color.WHITE, true, true);
            }

            float footer = h - dp(74);
            float half = (w - margin * 2 - gap) / 2f;
            wallpaperButton.set(margin, footer, margin + half, footer + dp(51));
            defaultButton.set(w - margin - half, footer, w - margin, footer + dp(51));
            button(canvas, wallpaperButton, "ЖИВЫЕ ОБОИ", false);
            button(canvas, defaultButton, "СДЕЛАТЬ ГЛАВНЫМ", false);

            if (animating && isShown()) postInvalidateDelayed(50L);
        }

        private void button(Canvas canvas, RectF area, String text, boolean active) {
            paint.reset(); paint.setAntiAlias(true);
            paint.setColor(active ? 0xE4F3ECCB : 0xC6184C5B);
            canvas.drawRoundRect(area, dp(13), dp(13), paint);
            label(canvas, text, area.centerX(), area.centerY() + dp(4), dp(10.5f),
                    active ? 0xFF194A56 : Color.WHITE, true, true);
        }

        private void label(Canvas canvas, String text, float x, float y, float size,
                           int color, boolean bold, boolean center) {
            paint.reset(); paint.setAntiAlias(true);
            paint.setColor(color); paint.setTextSize(size);
            paint.setTypeface(bold ? android.graphics.Typeface.create("sans-serif-medium", 1)
                    : android.graphics.Typeface.create("sans-serif", 0));
            paint.setTextAlign(center ? Paint.Align.CENTER : Paint.Align.LEFT);
            paint.setShadowLayer(dp(2), 0, dp(1), 0x99214752);
            canvas.drawText(text, x, y, paint);
            paint.clearShadowLayer();
        }

        private String shorten(String text, int max) {
            if (text.length() <= max) return text;
            return text.substring(0, max - 1) + "…";
        }

        private int hitIcon(float x, float y) {
            for (int i = iconBoxes.size() - 1; i >= 0; i--) {
                if (iconBoxes.get(i).contains(x, y)) return i;
            }
            return -1;
        }

        @Override public boolean onTouchEvent(MotionEvent event) {
            float x = event.getX(), y = event.getY();
            switch (event.getActionMasked()) {
                case MotionEvent.ACTION_DOWN:
                    startX = fingerX = x; startY = fingerY = y;
                    int index = hitIcon(x, y);
                    touched = index < 0 ? null : homeApps.get(index);
                    dragging = null;
                    if (touched != null) {
                        AppEntry selected = touched;
                        longPress = () -> {
                            if (touched == selected) {
                                dragging = selected;
                                performHapticFeedback(HapticFeedbackConstants.LONG_PRESS);
                                invalidate();
                            }
                        };
                        postDelayed(longPress, 440L);
                    }
                    return true;

                case MotionEvent.ACTION_MOVE:
                    fingerX = x; fingerY = y;
                    if (dragging != null) {
                        invalidate();
                    } else if (Math.hypot(x - startX, y - startY) > dp(14)) {
                        cancelPendingLongPress();
                    }
                    return true;

                case MotionEvent.ACTION_UP:
                    cancelPendingLongPress();
                    if (dragging != null) {
                        preferences.setIconPosition(dragging.key(),
                                clamp(x / getWidth(), .11f, .89f),
                                clamp(y / getHeight(), .30f, .80f));
                    } else if (Math.hypot(x - startX, y - startY) < dp(14)) {
                        if (touched != null) openApp(touched);
                        else if (beachButton.contains(x, y)) preferences.setTheme(SceneRenderer.BEACH);
                        else if (meadowButton.contains(x, y)) preferences.setTheme(SceneRenderer.MEADOW);
                        else if (appsButton.contains(x, y)) openDrawer();
                        else if (wallpaperButton.contains(x, y)) setLiveWallpaper();
                        else if (defaultButton.contains(x, y)) makeDefaultHome();
                    } else if (startY - y > dp(65) && touched == null) {
                        openDrawer();
                    }
                    dragging = null;
                    touched = null;
                    invalidate();
                    return true;

                case MotionEvent.ACTION_CANCEL:
                    cancelPendingLongPress(); dragging = null; touched = null; invalidate();
                    return true;
            }
            return true;
        }

        private void cancelPendingLongPress() {
            if (longPress != null) removeCallbacks(longPress);
            longPress = null;
        }

        private float clamp(float value, float min, float max) {
            return Math.min(max, Math.max(min, value));
        }
    }
}

