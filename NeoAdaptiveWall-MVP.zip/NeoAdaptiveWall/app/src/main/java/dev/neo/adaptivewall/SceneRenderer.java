package dev.neo.adaptivewall;

import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.graphics.Shader;

import java.util.List;

/** Paints a landscape that bends details away from occupied launcher icon areas. */
final class SceneRenderer {
    static final String BEACH = "beach";
    static final String MEADOW = "meadow";

    private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private float density;
    private int width;
    private int height;
    private float seconds;

    void render(Canvas canvas, int width, int height, float density, long uptime,
                String theme, List<RectF> iconZones) {
        this.density = density;
        this.width = width;
        this.height = height;
        this.seconds = uptime / 1000f;
        canvas.save();
        if (MEADOW.equals(theme)) {
            drawMeadow(canvas, iconZones);
        } else {
            drawBeach(canvas, iconZones);
        }
        canvas.restore();
    }

    private void drawBeach(Canvas canvas, List<RectF> zones) {
        gradient(canvas, 0, 0, width, height,
                Color.rgb(3, 67, 111), Color.rgb(6, 184, 184));

        // Glowing light filtered through the upper water.
        ellipse(canvas, width * .78f, height * .12f, width * .42f, height * .21f,
                0x273CFFFF);
        ellipse(canvas, width * .18f, height * .32f, width * .35f, height * .13f,
                0x1847F5E2);

        for (int i = 0; i < 7; i++) {
            float x = width * (.05f + i * .17f) + (float) Math.sin(seconds * .19f + i) * dp(17);
            float y = height * (.15f + (i % 3) * .17f);
            cloud(canvas, x, y, dp(30) + i * dp(2), 0x28E8FFEE);
        }

        // Moving wave crests are pushed around icon zones in real time.
        for (int i = 0; i < 16; i++) {
            float baseline = height * (.20f + i * .046f)
                    + (float) Math.sin(seconds * .57f + i * .68f) * dp(9);
            curvedWave(canvas, baseline, zones, i % 3 == 0 ? 0x82F2FFFF : 0x3CFFFFFF,
                    i % 3 == 0 ? dp(2.3f) : dp(1.2f));
        }

        // The shore is a deformable contour, including around bottom-row icons.
        Path sand = new Path();
        sand.moveTo(0, height);
        for (int x = 0; x <= width + dp(8); x += dp(8)) {
            float base = height * .82f + (float) Math.sin(x * .011f + seconds * .20f) * dp(14);
            sand.lineTo(x, repelLine(x, base, zones, dp(29)));
        }
        sand.lineTo(width, height);
        sand.close();
        fillPath(canvas, sand, 0xFFF1D39A);

        Path wetSand = new Path();
        for (int x = 0; x <= width + dp(8); x += dp(8)) {
            float base = height * .82f + (float) Math.sin(x * .011f + seconds * .20f) * dp(14);
            float y = repelLine(x, base, zones, dp(29));
            if (x == 0) wetSand.moveTo(x, y); else wetSand.lineTo(x, y);
        }
        strokePath(canvas, wetSand, 0xA5FFFFFF, dp(5));

        // Each placed icon becomes a protected sandbar. Moving it moves the sandbar.
        for (RectF zone : zones) {
            if (zone.centerY() < height * .78f) {
                ellipse(canvas, zone.centerX(), zone.centerY(),
                        zone.width() * .62f, zone.height() * .59f, 0x5DFBEBC5);
                ellipse(canvas, zone.centerX(), zone.centerY(),
                        zone.width() * .49f, zone.height() * .49f, 0x67E4F8E1);
            }
        }

        // Moving boat, tiny fish and shells stay clear of icon hitboxes.
        float boatX = width * (.13f + .70f * ((seconds * .013f) % 1f));
        float boatY = height * .145f + (float) Math.sin(seconds * 1.5f) * dp(3);
        if (!occupied(boatX, boatY, zones, dp(35))) {
            boat(canvas, boatX, boatY);
        }
        for (int i = 0; i < 23; i++) {
            float x = width * hash(i * 11 + 2);
            float y = height * (.25f + .67f * hash(i * 5 + 17));
            if (occupied(x, y, zones, dp(22))) continue;
            float wobble = (float) Math.sin(seconds * 1.2f + i) * dp(2);
            if (y > height * .80f) {
                shell(canvas, x, y, dp(4 + i % 4));
            } else {
                ellipse(canvas, x + wobble, y, dp(2.3f), dp(1.1f), 0x91E4FFF3);
            }
        }

        palm(canvas, width * .05f, height * .94f, dp(88), -1);
        palm(canvas, width * .98f, height * 1.01f, dp(115), 1);
    }

    private void drawMeadow(Canvas canvas, List<RectF> zones) {
        gradient(canvas, 0, 0, width, height,
                0xFF5EBCDC, 0xFFC5F0D1);
        ellipse(canvas, width * .78f, height * .16f, dp(40), dp(40), 0xB9FFF2BC);

        for (int i = 0; i < 5; i++) {
            float x = width * (i * .26f) + (float) Math.sin(seconds * .11f + i) * dp(25);
            float y = height * (.15f + (i % 2) * .09f);
            cloud(canvas, x, y, dp(32 + i * 5), 0xCFF5FFF8);
        }

        // The grassy ridges follow the occupied space; no flower is drawn below an icon.
        hill(canvas, height * .43f, dp(35), 0xFF83C8A5, zones);
        hill(canvas, height * .57f, dp(41), 0xFF55AB78, zones);
        hill(canvas, height * .72f, dp(29), 0xFF278A60, zones);

        for (int i = 0; i < 140; i++) {
            float x = width * hash(i * 37 + 5);
            float y = height * (.41f + hash(i * 19 + 31) * .57f);
            if (occupied(x, y, zones, dp(17))) continue;
            float sway = (float) Math.sin(seconds * 1.4f + i) * dp(2);
            int color = (i % 7 == 0) ? 0xFFFFD6A4 : (i % 5 == 0 ? 0xFFE8F9CD : 0xFFB9E8A3);
            flower(canvas, x + sway, y, dp(i % 9 == 0 ? 4 : 2.5f), color);
        }

        for (RectF zone : zones) {
            ellipse(canvas, zone.centerX(), zone.centerY(), zone.width() * .59f,
                    zone.height() * .58f, 0x3165E1AF);
        }

        for (int i = 0; i < 4; i++) {
            float x = width * hash(i * 17 + 12)
                    + (float) Math.sin(seconds * .35f + i) * dp(28);
            float y = height * (.34f + i * .12f)
                    + (float) Math.sin(seconds * 1.8f + i) * dp(11);
            if (!occupied(x, y, zones, dp(22))) butterfly(canvas, x, y, dp(5));
        }

        float catX = width * (.14f + .72f * ((seconds * .018f) % 1f));
        float catY = height * .90f + (float) Math.sin(seconds * 8f) * dp(2);
        if (!occupied(catX, catY, zones, dp(33))) cat(canvas, catX, catY);
    }

    private void hill(Canvas canvas, float baseline, float amplitude, int color, List<RectF> zones) {
        Path path = new Path();
        path.moveTo(0, height);
        for (int x = 0; x <= width + dp(8); x += dp(8)) {
            float y = baseline + (float) Math.sin(x * .008f + baseline) * amplitude;
            path.lineTo(x, repelLine(x, y, zones, dp(16)));
        }
        path.lineTo(width, height);
        path.close();
        fillPath(canvas, path, color);
    }

    private void curvedWave(Canvas canvas, float y, List<RectF> zones, int color, float stroke) {
        Path path = new Path();
        for (int x = 0; x <= width + dp(7); x += dp(7)) {
            float wave = y + (float) Math.sin(x * .023f + seconds * .72f) * dp(5);
            float bent = repelLine(x, wave, zones, dp(29));
            if (x == 0) path.moveTo(x, bent); else path.lineTo(x, bent);
        }
        strokePath(canvas, path, color, stroke);
    }

    private float repelLine(float x, float y, List<RectF> zones, float padding) {
        float result = y;
        for (RectF zone : zones) {
            float dx = Math.abs(x - zone.centerX());
            float reachX = zone.width() * .64f + padding;
            float reachY = zone.height() * .56f + padding;
            float dy = result - zone.centerY();
            if (dx >= reachX || Math.abs(dy) >= reachY) continue;
            float fade = (float) Math.pow(Math.cos(dx / reachX * Math.PI * .5), 2);
            float displacement = (reachY - Math.abs(dy)) * fade;
            result += (dy >= 0 ? 1 : -1) * displacement;
        }
        return result;
    }

    private boolean occupied(float x, float y, List<RectF> zones, float padding) {
        for (RectF zone : zones) {
            if (x >= zone.left - padding && x <= zone.right + padding
                    && y >= zone.top - padding && y <= zone.bottom + padding) return true;
        }
        return false;
    }

    private void cloud(Canvas c, float x, float y, float radius, int color) {
        ellipse(c, x, y, radius, radius * .29f, color);
        ellipse(c, x - radius * .36f, y - radius * .13f, radius * .44f, radius * .38f, color);
        ellipse(c, x + radius * .22f, y - radius * .19f, radius * .47f, radius * .44f, color);
    }

    private void boat(Canvas c, float x, float y) {
        Path hull = new Path();
        hull.moveTo(x - dp(14), y); hull.lineTo(x + dp(15), y);
        hull.lineTo(x + dp(8), y + dp(9)); hull.lineTo(x - dp(9), y + dp(9));
        hull.close(); fillPath(c, hull, 0xFFD87750);
        Path sail = new Path();
        sail.moveTo(x + dp(2), y - dp(25)); sail.lineTo(x + dp(2), y - dp(2));
        sail.lineTo(x - dp(13), y - dp(2)); sail.close(); fillPath(c, sail, 0xFFEFFFDD);
        line(c, x + dp(2), y - dp(28), x + dp(2), y, 0xFF3B5965, dp(1.2f));
    }

    private void shell(Canvas c, float x, float y, float r) {
        ellipse(c, x, y, r, r * .64f, 0xFFFAE4BA);
        for (int i = -1; i <= 1; i++) {
            line(c, x, y + r * .5f, x + i * r * .65f, y - r * .4f, 0xFFCEAE88, dp(.7f));
        }
    }

    private void palm(Canvas c, float x, float y, float length, int direction) {
        Path trunk = new Path();
        trunk.moveTo(x, y);
        trunk.cubicTo(x + direction * length * .12f, y - length * .4f,
                x + direction * length * .28f, y - length * .8f,
                x + direction * length * .20f, y - length);
        strokePath(c, trunk, 0xFF7A5946, dp(7));
        float topX = x + direction * length * .20f;
        float topY = y - length;
        for (int i = 0; i < 7; i++) {
            float angle = (float) (-Math.PI * .95 + i * Math.PI / 5);
            float endX = topX + (float) Math.cos(angle) * length * .54f;
            float endY = topY + (float) Math.sin(angle) * length * .36f;
            Path leaf = new Path(); leaf.moveTo(topX, topY);
            leaf.quadTo((topX + endX) / 2, topY - dp(16), endX, endY);
            strokePath(c, leaf, 0xFF164D4A, dp(7));
        }
    }

    private void flower(Canvas c, float x, float y, float radius, int color) {
        line(c, x, y + radius * 2, x, y - radius, 0x8E206944, dp(1));
        for (int i = 0; i < 5; i++) {
            double a = i * Math.PI * 2 / 5;
            ellipse(c, x + (float) Math.cos(a) * radius, y + (float) Math.sin(a) * radius,
                    radius * .78f, radius * .78f, color);
        }
        ellipse(c, x, y, radius * .6f, radius * .6f, 0xFFFFD467);
    }

    private void butterfly(Canvas c, float x, float y, float r) {
        ellipse(c, x - r * .6f, y - r * .5f, r, r * .67f, 0xDFFFF1B7);
        ellipse(c, x + r * .6f, y - r * .5f, r, r * .67f, 0xE3FCE4B7);
        ellipse(c, x, y, r * .19f, r, 0xFF5E705A);
    }

    private void cat(Canvas c, float x, float y) {
        float s = dp(17);
        Path tail = new Path(); tail.moveTo(x + s * .4f, y);
        tail.cubicTo(x + s * 1.4f, y + s * .2f, x + s * 1.3f, y - s * 1.8f,
                x + s * 1.85f, y - s * 1.45f);
        strokePath(c, tail, 0xFF202F36, dp(5));
        ellipse(c, x, y, s * .74f, s * .50f, 0xFF202F36);
        ellipse(c, x - s * .5f, y - s * .53f, s * .4f, s * .42f, 0xFF202F36);
        Path ears = new Path(); ears.moveTo(x - s * .85f, y - s * .7f);
        ears.lineTo(x - s * .85f, y - s * 1.2f); ears.lineTo(x - s * .5f, y - s * .86f);
        ears.lineTo(x - s * .22f, y - s * 1.25f); ears.lineTo(x - s * .15f, y - s * .64f);
        ears.close(); fillPath(c, ears, 0xFF202F36);
        ellipse(c, x - s * .63f, y - s * .58f, dp(1.6f), dp(1.6f), 0xFFFFE9A3);
    }

    private void gradient(Canvas c, float x1, float y1, float x2, float y2, int top, int bottom) {
        prepare(0xFFFFFFFF);
        paint.setShader(new LinearGradient(x1, y1, x1, y2, top, bottom, Shader.TileMode.CLAMP));
        c.drawRect(x1, y1, x2, y2, paint);
        paint.setShader(null);
    }

    private void ellipse(Canvas c, float x, float y, float rx, float ry, int color) {
        prepare(color); c.drawOval(x - rx, y - ry, x + rx, y + ry, paint);
    }

    private void line(Canvas c, float x1, float y1, float x2, float y2, int color, float stroke) {
        prepare(color); paint.setStyle(Paint.Style.STROKE); paint.setStrokeWidth(stroke);
        paint.setStrokeCap(Paint.Cap.ROUND); c.drawLine(x1, y1, x2, y2, paint);
    }

    private void fillPath(Canvas c, Path path, int color) {
        prepare(color); c.drawPath(path, paint);
    }

    private void strokePath(Canvas c, Path path, int color, float stroke) {
        prepare(color); paint.setStyle(Paint.Style.STROKE); paint.setStrokeWidth(stroke);
        paint.setStrokeCap(Paint.Cap.ROUND); paint.setStrokeJoin(Paint.Join.ROUND);
        c.drawPath(path, paint);
    }

    private void prepare(int color) {
        paint.reset(); paint.setAntiAlias(true); paint.setColor(color);
    }

    private float dp(float val) { return val * density; }

    private static float hash(int value) {
        int h = value * 1103515245 + 12345;
        return (h >>> 8 & 65535) / 65535f;
    }
}

