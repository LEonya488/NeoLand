package dev.neo.adaptivewall;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.PointF;

final class ScenePrefs {
    private static final String PREFS = "neo_land_v1";
    private final SharedPreferences storage;

    ScenePrefs(Context context) {
        storage = context.getApplicationContext().getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }

    String theme() {
        return storage.getString("theme", SceneRenderer.BEACH);
    }

    void setTheme(String value) {
        storage.edit().putString("theme", value).apply();
    }

    String pinned() { return storage.getString("pinned", null); }

    void setPinned(String flattened) {
        storage.edit().putString("pinned", flattened).apply();
    }

    PointF getIconPosition(String component, int index) {
        float defaultX = .155f + (index % 4) * .23f;
        float defaultY = .365f + (index / 4) * .116f;
        float x = storage.getFloat("x_" + component, defaultX);
        float y = storage.getFloat("y_" + component, defaultY);
        return new PointF(x, y);
    }

    void setIconPosition(String component, float x, float y) {
        storage.edit().putFloat("x_" + component, x)
                .putFloat("y_" + component, y).apply();
    }
}

