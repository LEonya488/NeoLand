package dev.neo.adaptivewall;

import android.graphics.Canvas;
import android.graphics.RectF;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.service.wallpaper.WallpaperService;
import android.view.SurfaceHolder;

import java.util.Collections;
import java.util.List;

/** Standard Android live wallpaper. Icon-aware adaptation lives in HomeActivity. */
public final class AdaptiveWallpaperService extends WallpaperService {
    @Override
    public Engine onCreateEngine() {
        return new LandscapeEngine();
    }

    private final class LandscapeEngine extends Engine {
        private final Handler handler = new Handler(Looper.getMainLooper());
        private final SceneRenderer renderer = new SceneRenderer();
        private final ScenePrefs preferences = new ScenePrefs(AdaptiveWallpaperService.this);
        private final List<RectF> emptyZones = Collections.emptyList();
        private boolean visible;
        private int surfaceWidth;
        private int surfaceHeight;

        private final Runnable animation = new Runnable() {
            @Override public void run() { drawFrame(); }
        };

        @Override public void onVisibilityChanged(boolean visible) {
            this.visible = visible;
            handler.removeCallbacks(animation);
            if (visible) drawFrame();
        }

        @Override public void onSurfaceChanged(SurfaceHolder holder, int format,
                                               int width, int height) {
            super.onSurfaceChanged(holder, format, width, height);
            surfaceWidth = width;
            surfaceHeight = height;
            if (visible) drawFrame();
        }

        @Override public void onSurfaceDestroyed(SurfaceHolder holder) {
            visible = false;
            handler.removeCallbacks(animation);
            super.onSurfaceDestroyed(holder);
        }

        @Override public void onDestroy() {
            visible = false;
            handler.removeCallbacks(animation);
            super.onDestroy();
        }

        private void drawFrame() {
            handler.removeCallbacks(animation);
            if (!visible || surfaceWidth <= 0 || surfaceHeight <= 0) return;
            Canvas canvas = null;
            try {
                canvas = getSurfaceHolder().lockCanvas();
                if (canvas != null) {
                    renderer.render(canvas, surfaceWidth, surfaceHeight,
                            getResources().getDisplayMetrics().density,
                            SystemClock.uptimeMillis(), preferences.theme(), emptyZones);
                }
            } catch (IllegalArgumentException | IllegalStateException ignored) {
                // The system may destroy the surface between the check and lockCanvas.
            } finally {
                if (canvas != null) {
                    try { getSurfaceHolder().unlockCanvasAndPost(canvas); }
                    catch (IllegalStateException ignored) { }
                }
            }
            if (visible) handler.postDelayed(animation, 50L);
        }
    }
}

